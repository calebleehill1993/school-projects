#include "Token.h"
#include <vector>
#include <fstream>
#include <iostream>
class LexicalAnalyzer
{
public:
	LexicalAnalyzer();
	LexicalAnalyzer(std::ifstream& inFile);
	~LexicalAnalyzer();
	std::vector<Token> tokens;
	void Print();
	void oneLineComment(std::string line, int lineNumber, int i);
};

