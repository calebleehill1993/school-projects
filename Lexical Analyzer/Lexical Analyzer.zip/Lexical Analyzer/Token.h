#include <string>
#include <iostream>
enum tokenType
{
	COMMA,
	PERIOD,
	Q_MARK,
	LEFT_PAREN,
	RIGHT_PAREN,
	COLON,
	COLON_DASH,
	MULTIPLY,
	ADD,
	SCHEMES,
	FACTS,
	RULES,
	QUERIES,
	ID,
	STRING,
	COMMENT,
	WHITESPACE,
	UNDEFINED,
	//EOF NEEDED TO BE HERE
};
class Token
{
public:
	Token(std::string a, std::string b, std::int32_t c);
	~Token();
	std::string string;
	std::int32_t number;
	std::string type;
	void Print();
};

