#include "LexicalAnalyzer.h"
#include <ctype.h>


LexicalAnalyzer::LexicalAnalyzer()
{
}

LexicalAnalyzer::LexicalAnalyzer(std::ifstream& inFile)
{
	std::string line;
	std::int32_t lineNumber = 1;
	std::string carryString = ""; //String used for multiple lines.
	std::int32_t carryNumber = 0; //To keep track of line number when token on multiple lines.
	bool tokenTypeString = false;
	bool tokenTypeComment = false;
	while (getline(inFile, line))
	{
		std::string s = "";
		std::int32_t l = line.length() - 1;
		for (unsigned int i = 0; i < line.length(); i++)
		{
			std::int32_t ascii = (int)line.at(i); //Gets the ascii number for the character

			if (tokenTypeString && line.at(i) == '\'')
			{
				while (i < l && line.substr(i, 2) == "\'\'")
				{
					s += "\'\'";
					i += 2;
				}
				if (line.at(i) == '\'' && line.at(i + 1) != '\'')
				{
					Token t = Token("STRING", "\"" + carryString + "\'\"", carryNumber);
					tokens.push_back(t);
					tokenTypeString = false;
					carryString = "";
					carryNumber = 0;
				}
			}
			else if (tokenTypeString)
			{
				char character = line.at(i);
				do
				{
					s += line.at(i);
					i++;
					while (i < l && line.substr(i, 2) == "\'\'")
					{
						s += "\'\'";
						i += 2;
					}
					if (i <= l)
					{
						character = line.at(i);
					}
					else
					{
						character = '0';
						carryString += s + "\n";
						tokenTypeString = true;
						break;
					}
				} while (character != '\'');
				if (character != '0')
				{
					Token t = Token("STRING", "\"" + carryString + s + "\'\"", carryNumber);
					tokens.push_back(t);
					tokenTypeString = false;
					carryString = "";
					carryNumber = 0;
				}
			}
			else if (tokenTypeComment && i < l && line.substr(i, 2) == "|#")
			{
				Token t = Token("COMMENT", "\"" + carryString + "|#\"", carryNumber);
				tokens.push_back(t);
				tokenTypeComment = false;
				carryString = "";
				carryNumber = 0;
				i++;
			}
			else if (tokenTypeComment)
			{
				s = "";
				char character = line.at(i);
				std::string substring = "";
				do
				{
					s += character;
					i++;
					if (i < l)
					{
						substring = line.substr(i, 2);
					}
					if (i <= l)
					{
						character = line.at(i);
					}
					else
					{
						character = '0';
						carryString += s + "\n";
						tokenTypeComment = true;
						break;
					}
				} while (substring != "|#");
				if (!tokenTypeComment)
				{
					Token t = Token("COMMENT", "\"" + carryString + "|#\"", carryNumber);
					tokens.push_back(t);
					tokenTypeComment = false;
					carryString = "";
					carryNumber = 0;
				}
			}
			//FOR BLOCK COMMENTS
			else if (i < l && line.substr(i, 2) == "#|")
			{
				s = "#";
				i++;
				char character = line.at(i);
				std::string substring = "";
				do
				{
					s += character;
					i++;
					if (i < l)
					{
						substring = line.substr(i, 2);
					}
					if (i <= l)
					{
						character = line.at(i);
					}
					else
					{
						character = '0';
						carryString = s + "\n";
						carryNumber = lineNumber;
						tokenTypeComment = true;
						break;
					}
				} while (substring != "|#");
				if (!tokenTypeComment)
				{
					Token t = Token("COMMENT", "\"" + s + "|#\"", lineNumber);
					tokens.push_back(t);
					i++;
				}
			}
			//FOR ONE LINE COMMENTS
			else if (line.at(0) == '#')
			{
				Token t = Token("COMMENT", "\"" + line + "\"", lineNumber);
				tokens.push_back(t);
				i = line.length();
			}
			else if (line.at(i) == ',')
			{
				Token t = Token("COMMA", "\",\"", lineNumber);
				tokens.push_back(t);
			}
			else if (line.at(i) == '.')
			{
				Token t = Token("PERIOD", "\".\"", lineNumber);
				tokens.push_back(t);
			}
			else if (line.at(i) == '?')
			{
				Token t = Token("Q_MARK", "\"?\"", lineNumber);
				tokens.push_back(t);
			}
			else if (line.at(i) == '(')
			{
				Token t = Token("LEFT_PAREN", "\"(\"", lineNumber);
				tokens.push_back(t);
			}
			else if (line.at(i) == ')')
			{
				Token t = Token("RIGHT_PAREN", "\")\"", lineNumber);
				tokens.push_back(t);
			}
			else if (line.substr(i, 2) == ":-")
			{
				Token t = Token("COLON_DASH", "\":-\"", lineNumber);
				i++;
				tokens.push_back(t);
			}
			else if (line.at(i) == ':')
			{
				Token t = Token("COLON", "\":\"", lineNumber);
				tokens.push_back(t);
			}
			else if (line.at(i) == '*')
			{
				Token t = Token("MULTIPLY", "\"*\"", lineNumber);
				tokens.push_back(t);
			}
			else if (line.at(i) == '+')
			{
				Token t = Token("ADD", "\"+\"", lineNumber);
				tokens.push_back(t);
			}
			else if (line.substr(i, 7) == "Schemes")
			{
				Token t = Token("SCHEMES", "\"Schemes\"", lineNumber);
				i += 6;
				tokens.push_back(t);
			}
			else if (line.substr(i, 5) == "Facts")
			{
				Token t = Token("FACTS", "\"Facts\"", lineNumber);
				i += 4;
				tokens.push_back(t);
			}
			else if (line.substr(i, 5) == "Rules")
			{
				Token t = Token("RULES", "\"Rules\"", lineNumber);
				i += 4;
				tokens.push_back(t);
			}
			else if (line.substr(i, 7) == "Queries")
			{
				Token t = Token("QUERIES", "\"Queries\"", lineNumber);
				i += 6;
				tokens.push_back(t);
			}
			//FOR STRINGS
			else if (line.at(i) == '\'')
			{
				s = "";
				char character = line.at(i);
				do
				{
					s += line.at(i);
					i++;
					while (i < l && line.substr(i, 2) == "\'\'")
					{
						s += "\'\'";
						i += 2;
					}
					if (i <= l)
					{
						character = line.at(i);
					}
					else
					{
						character = '0';
						carryString = s + "\n";
						carryNumber = lineNumber;
						tokenTypeString = true;
						break;
					}
				} while (character != '\'');
				if (!tokenTypeString)
				{
					Token t = Token("STRING", "\"" + s + "\'\"", lineNumber);
					tokens.push_back(t);
				}

			}
			else if ((ascii >= 65 && ascii <= 90) || (ascii >= 97 && ascii <= 122)) //Finds any letter
			{
				s = "";
				do
				{
					s += line.at(i);
					i++;
					if (i <= l)
					{
						ascii = (int)line.at(i);
					}
					else
					{
						ascii = 0;
					}
				} while ((ascii >= 48 && ascii <= 57) || (ascii >= 65 && ascii <= 90) || (ascii >= 97 && ascii <= 122)); //Finds letters and numbers
				Token t = Token("ID", "\"" + s + "\"", lineNumber);
				tokens.push_back(t);
				i--;
			}
			else if (isspace(line.at(i))) {}
			else
			{
				Token t = Token("UNDEFINED", "\"" + line.substr(i, 1) + "\"", lineNumber);
				tokens.push_back(t);
			}
		}
		lineNumber++;
	}
	if (carryString != "")
	{
		Token t = Token("UNDEFINED", "\"" + carryString + "\"", carryNumber);
		tokens.push_back(t);
	}
	Token t = Token("EOF", "\"\"", lineNumber);
	tokens.push_back(t);
}


LexicalAnalyzer::~LexicalAnalyzer()
{
}

void LexicalAnalyzer::Print()
{
	for (unsigned int i = 0; i < tokens.size(); i++)
	{
		tokens.at(i).Print();
	}
	std::cout << "Total Tokens = " << tokens.size() << std::endl;
}