using namespace std;
#include "LexicalAnalyzer.h"
#include <fstream>

int main(int argc, char *argv[])
{
	ifstream input;
	input.open(argv[1]);
	LexicalAnalyzer la = LexicalAnalyzer(input);
	la.Print();
	system("Pause");
	return 0;
};