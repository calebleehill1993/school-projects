#include "Commercial.h"



Commercial::Commercial(string NewAddress, int NewId)
{
	address = NewAddress;
	id = NewId;
}


Commercial::~Commercial()
{
}
