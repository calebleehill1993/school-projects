#include "Residential.h"



Residential::Residential(string NewAddress, int NewId)
{
	address = NewAddress;
	id = NewId;
}


Residential::~Residential()
{
}
