/*
Caleb Hill, Section __, calebleehill1993@gmail.com

Purpose: Copy the program given to me in lab 1

Inputs: No inputs

Outputs:
	BYU trivia questions and answers
*/

#include <iostream>

using namespace std;

int main()
{
	cout << "\t\t\t\tBasic BYU Trivia\n\n";

	cout << "\t\tQuestions\t\t\t\tAnswers\n\n";

	cout << "What was the original name of BYU?\t\tBrigham Young Academy\n";

	cout << "When was BYA established?\t\t\t1875\n";

	cout << "Who was the first \"permanent\" principal of BYA?\tKarl Maeser\n";

	cout << "When did BYA become BYU?\t\t\t1903\n";

	cout << "To what sports conference do we belong?\t\tIndependent (Football)\n";

	cout << "When did BYU win the national football title?\t1984\n";

	cout << "Who won the Heisman Trophy in 1990?\t\tTy Detmer\n";

	system("pause");

	return 0;
}