#ifndef CSG_H_
#define CSG_H_
#endif // !CSG_H_

class Csg
{
private:
	string courseName;
	int studentID;
	string studentGrade;
public:
	Csg();
	~Csg();
};

