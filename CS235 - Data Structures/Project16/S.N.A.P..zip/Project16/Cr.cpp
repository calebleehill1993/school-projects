#include "Cr.h"



Cr::Cr()
{
}


Cr::~Cr()
{
}
