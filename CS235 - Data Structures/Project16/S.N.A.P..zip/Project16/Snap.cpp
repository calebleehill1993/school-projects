#include "Snap.h"



Snap::Snap()
{
}


Snap::~Snap()
{
}
