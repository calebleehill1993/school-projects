#ifndef SNAP_H_
#define SNAP_H_
#endif // !SNAP_H_

class Snap
{
private:
	int studentID;
	string studentName;
	string studentAddress;
	string studentPhone;
public:
	Snap();
	~Snap();
};

