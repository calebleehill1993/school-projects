#ifndef CDH_H_
#define CDH_H_
#endif // !CDH_H_

class Cdh
{
private:
	string courseName;
	string day;
	string time;
public:
	Cdh();
	~Cdh();
};

