#ifndef CR_H_
#define CR_H_
#endif // !CR_H_

class Cr
{
private:
	string courseName;
	string room;
public:
	Cr();
	~Cr();
};

